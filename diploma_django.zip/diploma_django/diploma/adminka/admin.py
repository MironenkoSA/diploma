from django.contrib import admin
from .models import Price
from .models import Port
from .models import Feedback
from .models import Map

class PriceAdmin(admin.ModelAdmin):
    list_display = ('Название_услуги', 'Стоимость_услуги', 'Время_исполнения')

class PortAdmin(admin.ModelAdmin):
    list_display = ('Название_проекта', 'Заказчик', 'Время_исполнения')

class FeedbackAdmin(admin.ModelAdmin):
    list_display = ('fb_name', 'fb_number', 'fb_email', 'fb_date')




admin.site.register(Price, PriceAdmin)
admin.site.register(Port, PortAdmin)
admin.site.register(Feedback, FeedbackAdmin)
admin.site.register(Map)
# Register your models here.
