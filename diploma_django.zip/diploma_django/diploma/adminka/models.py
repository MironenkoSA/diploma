from tabnanny import verbose
from django.db import models


class Price(models.Model):
    Название_услуги = models.CharField(max_length=60)
    Стоимость_услуги = models.CharField(max_length= 40)
    Время_исполнения = models.CharField(max_length= 40)

    def __str__(self):
        return self.название_услуги
    class Meta:
        verbose_name='Прайс'
        verbose_name_plural='Прайс'
    
class Port(models.Model):
    Название_проекта = models.CharField(max_length=60)
    Заказчик = models.CharField(max_length=40)
    Время_исполнения = models.CharField(max_length=40)

    def __str__(self):
        return self.Название_проекта
    
    class Meta:
        verbose_name='Портфолио'
        verbose_name_plural='Портфолио'

class Feedback(models.Model):
    fb_text = models.CharField(max_length=255)
    fb_name = models.CharField(max_length=80)
    fb_number = models.CharField(max_length=12, blank=True)
    fb_email = models.CharField(max_length=60)
    fb_date = models.DateTimeField(auto_now_add=True)
    fb_type = models.CharField(max_length=14)

    class Meta:
        verbose_name='Отзывы'
        verbose_name_plural='Отзывы'

class Map(models.Model):
    Карта = models.CharField(max_length=255)

    class Meta:
        verbose_name='Карта'
        verbose_name_plural='Карта'
